exports.run = async (client, message, args, level) => {// eslint-disable-line no-unused-vars
  // INSERT COMMAND ACTIONS HERE
};

exports.conf = {
  enabled: false,
  guildOnly: false,
  aliases: [],
  permLevel: "User"
};

exports.help = {
  name: "example",
  category: "Miscellaneous",
  description: "A standard issue example command.",
  usage: ";example"
};
